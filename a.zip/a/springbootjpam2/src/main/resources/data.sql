
insert into Books (book_id,book_name,book_edition,book_free)values(1,'Bangalore',1,'Available');
insert into Books (book_id,book_name,book_edition,book_free)values(2,'Bangalore',2,'Available');
insert into Books (book_id,book_name,book_edition,book_free)values(3,'Delhi',1,'Available');
insert into Books (book_id,book_name,book_edition,book_free)values(4,'Gujarat',1,'Available');
insert into Books (book_id,book_name,book_edition,book_free)values(5,'Gujarat',2,'Available');
insert into Books (book_id,book_name,book_edition,book_free)values(6,'India',1,'Available');
insert into Books (book_id,book_name,book_edition,book_free)values(7,'Bangalore',1,'Available');

insert into members (member_id,member_name,member_type,book_one,book_two)values(1,'jaimin','Titanium',0,0);
insert into members (member_id,member_name,member_type,book_one,book_two)values(2,'nayana','Premium',0,0);
insert into members (member_id,member_name,member_type,book_one,book_two)values(3,'chandana','Premium',0,0);
insert into members (member_id,member_name,member_type,book_one,book_two)values(4,'aswin','Premium',0,0);
insert into members (member_id,member_name,member_type,book_one,book_two)values(5,'salman','Titanium',0,0);
insert into members (member_id,member_name,member_type,book_one,book_two)values(6,'shahrukh','Titanium',0,0);

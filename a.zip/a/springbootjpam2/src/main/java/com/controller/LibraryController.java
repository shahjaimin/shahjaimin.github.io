package com.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.Books;
import com.model.Members;
import com.model.Tranactions;
import com.model.UserDate;
import com.service.IBooksService;
import com.service.IMembersService;
import com.service.ITransactionsService;

@Controller
public class LibraryController {
	
	@Autowired
	IMembersService memberservice;
	
	@Autowired
	ITransactionsService transactionservice;
	
	@Autowired
	IBooksService bookservice;
	
	
	UserDate date=new UserDate();
	
	@RequestMapping("/")
	public String home()
	{
		return "home.jsp";
	}
	
	
	@RequestMapping("/returnbook")
	public ModelAndView bookreturn(@RequestParam int book_id,@RequestParam int member_id) throws ParseException
	{
		
		ModelAndView mv=null;
		if(bookservice.bookexistsById(book_id) && memberservice.memberexistsById(member_id))
		{
		
		
		int id= transactionservice.get_transaction(book_id,member_id);
		
			transactionservice.update(id,date.getToday());
			
			bookservice.book_update_available(book_id);
			Members member=memberservice.memberfindById(member_id);
			if(member.getBook_one()==book_id)
			{
				memberservice.book_one_return(member_id);
			}
			else
			{
				memberservice.book_two_return(member_id);
			}
			
			
		
		
		}
		else
		{
			mv=new ModelAndView("error.jsp");
			 mv.addObject("msg", "Sorry, This type of BookID OR MemberID not in database");
		}
		return mv;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("/issuebook")
	public ModelAndView bookissue(@RequestParam int book_id,@RequestParam int member_id) throws ParseException
	{
		
		ModelAndView mv=null;
		if(bookservice.bookexistsById(book_id) && memberservice.memberexistsById(member_id))
		{
		Books book=bookservice.bookfindById(book_id);
		if("Available".equalsIgnoreCase(book.getBook_free()))
		{
			Members member=memberservice.memberfindById(member_id);
			if("Premium".equalsIgnoreCase(member.getMember_type()))
			{
				if(member.getBook_one()==0)
				{
					
						// Update Book availability
						bookservice.updatebook_free(book_id);
					
						// Update Members by issued Book
						memberservice.updatemember_bookone(book_id, member_id);
					
					// Create and Save Book Issue Transaction
					Tranactions t=new Tranactions();
					t.setBook_id(book.getBook_id());
					t.setMember_id(member.getMember_id());
					t.setIssue_date(date.getToday());
					t.setReturn_date(date.getToday_seven());
					t.setReturned_date("No");
					transactionservice.transactionsave(t);
					
						
					mv=new ModelAndView("success.jsp");
					mv.addObject("msg","Book with id: "+book_id+" issued to Member: "+member_id+" Successfully");
				}
				else
				{
					mv=new ModelAndView("error.jsp");
					mv.addObject("msg","you have already taken book of book id: "+ member.getBook_one()+""+", please return that first");
					
				}
			}
			else if("Titanium".equalsIgnoreCase(member.getMember_type()))
			{
				if(member.getBook_one()==0)
				{
					
					// Update Book availability
					bookservice.updatebook_free(book_id);
				
					// Update Members by issued Book
					memberservice.updatemember_bookone(book_id, member_id);
				
				// Create and Save Book Issue Transaction
				Tranactions t=new Tranactions();
				t.setBook_id(book.getBook_id());
				t.setMember_id(member.getMember_id());
				t.setIssue_date(date.getToday());
				t.setReturn_date(date.getToday_seven());
				t.setReturned_date("No");
				transactionservice.transactionsave(t);
				
					mv=new ModelAndView("success.jsp");
					mv.addObject("msg","Book with id: "+book_id+" issued to Member: "+member_id+" Successfully");
					}
				else if(member.getBook_two()==0)
				{
					
					
					// Update Book availability
					bookservice.updatebook_free(book_id);
				
					// Update Members by issued Book
					memberservice.updatemember_booktwo(book_id, member_id);
				
				// Create and Save Book Issue Transaction
				Tranactions t=new Tranactions();
				t.setBook_id(book.getBook_id());
				t.setMember_id(member.getMember_id());
				t.setIssue_date(date.getToday());
				t.setReturn_date(date.getToday_seven());
				t.setReturned_date("No");
				transactionservice.transactionsave(t); 
				
					mv=new ModelAndView("success.jsp");
					mv.addObject("msg","Book with id: "+book_id+" issued to Member: "+member_id+" Successfully");
					}
				else
				{
					
					mv=new ModelAndView("error.jsp");
					mv.addObject("msg","you have already taken book of book id: "+ member.getBook_one()+" and "
					+ member.getBook_two()+", please return that first");
				}
			}
		}
		else
		{
			
			 mv=new ModelAndView("error.jsp");
			 mv.addObject("msg","Sorry this Book is not available in library");
		}
		}
		else
		{
			
			 mv=new ModelAndView("error.jsp");
			 mv.addObject("msg", "Sorry, This type of BookID OR MemberID not in database");
		}
		return mv;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}

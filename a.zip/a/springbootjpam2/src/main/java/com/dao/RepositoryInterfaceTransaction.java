package com.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.model.Tranactions;

public interface RepositoryInterfaceTransaction extends JpaRepository<Tranactions, Integer>{


	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update Tranactions t1 set t1.returned_date =:sDate where t1.trans_id=:id")
	void update(@Param("sDate") String sDate,@Param("id") int id);

	
	@Query("select t1.trans_id from Tranactions t1 where t1.returned_date ='No' and t1.book_id=:book_id and t1.member_id=:member_id")
	int get_transaction(@Param("book_id") int book_id,@Param("member_id") int member_id);


}

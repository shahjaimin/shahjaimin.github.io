package com.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.model.Members;

public interface RepositoryInterfaceMembers  extends JpaRepository<Members, Integer>{
	
	@Transactional
	@Modifying(clearAutomatically = true)
    @Query("UPDATE Members c SET c.book_one = :book_id WHERE c.member_id = :member_id")
	public void updatemember_bookone(@Param("book_id") int book_id,@Param("member_id") int member_id);
	
	@Transactional
	@Modifying(clearAutomatically = true)
    @Query("UPDATE Members c SET c.book_two = :book_id WHERE c.member_id = :member_id")
	public void updatemember_booktwo(@Param("book_id") int book_id,@Param("member_id") int member_id);

	@Transactional
	@Modifying(clearAutomatically = true)
    @Query("UPDATE Members c SET c.book_one = 0 WHERE c.member_id = :member_id")
	public void book_one_return(int member_id);

	@Transactional
	@Modifying(clearAutomatically = true)
    @Query("UPDATE Members c SET c.book_two = 0 WHERE c.member_id = :member_id")
	public void book_two_return(int member_id);
	
	
	
}

package com.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.model.Members;


@Component
public class MembersDaoImpl implements MemberDao{
	
	@Autowired
	private RepositoryInterfaceMembers impl;
	

	@Override
	public void updatemember_bookone(int book_id,int member_id)
	{
		impl.updatemember_bookone(book_id, member_id);
	}
	@Override
	public void updatemember_booktwo(int book_id,int member_id)
	{
		impl.updatemember_booktwo(book_id, member_id);
	}

	@Override
	public boolean memberexistsById(int member_id) {
		// TODO Auto-generated method stub
		return  impl.existsById(member_id);
	}

	@Override
	public Members memberfindById(int member_id) {
		// TODO Auto-generated method stub
		return  impl.findById(member_id).orElse(new Members());
	}

	@Override
	public void memberdeletebyid(int member_id) {
		// TODO Auto-generated method stub
		impl.deleteById(member_id);
		
	}

	@Override
	public void membersavebyid(Members member) {
		// TODO Auto-generated method stub
		impl.save(member);
		
	}
	@Override
	public void book_one_return(int member_id) {
		impl.book_one_return(member_id);
		
	}
	@Override
	public void book_two_return(int member_id) {
		impl.book_two_return(member_id);
		
	}

	

}

package com.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.model.Tranactions;

@Transactional
@Component
public class TransactionsDaoImpl implements TransactionDao{
	@Autowired
	private RepositoryInterfaceTransaction impl;

	@Override
	public void transactionsave(Tranactions t) {
		impl.save(t);
		
	}

	@Override
	public int get_transaction(int book_id, int member_id) {
		// TODO Auto-generated method stub
		
		return impl.get_transaction(book_id,member_id);
		 
	}

	@Override
	public void update(int id,String sDate) {
		impl.update(sDate,id);
		
	}


	
	

}

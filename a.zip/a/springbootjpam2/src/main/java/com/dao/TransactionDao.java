package com.dao;



import com.model.Tranactions;


public interface TransactionDao{

	

	void transactionsave(Tranactions t);

	int get_transaction(int book_id, int member_id);

	void update(int id,String sDate);



}

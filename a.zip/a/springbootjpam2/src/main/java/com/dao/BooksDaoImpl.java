package com.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.model.Books;



@Transactional
@Component
public class BooksDaoImpl implements BooksDao
{
	@Autowired
	private RepositoryInterfaceBooks impl;
	
	public boolean bookexistsById(int book_id) {
		
		return impl.existsById(book_id);
	}
	public Books bookfindById(int book_id) {
		
		return impl.findById(book_id).orElse(new Books());
	}
	
	public void updatebook_free(int book_id)
	{
		impl.updatebook_free(book_id);
	}
	@Override
	public void boookdeletebyid(int book_id) {
		impl.deleteById(book_id);
		
	}
	@Override
	public void booksavebyid(Books book) {
		impl.save(book);
		
	}
	@Override
	public void book_update_available(int book_id) {
		impl.book_update_available(book_id);
		
	}
}

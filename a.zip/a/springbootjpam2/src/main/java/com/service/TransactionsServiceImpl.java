package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.TransactionDao;
import com.model.Tranactions;

@Service
public class TransactionsServiceImpl implements ITransactionsService{

	@Autowired
	TransactionDao transactiondao;
	@Override
	public void transactionsave(Tranactions t) {
		transactiondao.transactionsave(t);
		
	}
	@Override
	public int get_transaction(int book_id, int member_id) {
		// TODO Auto-generated method stub
		return transactiondao.get_transaction(book_id,member_id);
	}
	@Override
	public void update(int id,String sDate) {
		transactiondao.update(id,sDate);
		
	}
	
	

}

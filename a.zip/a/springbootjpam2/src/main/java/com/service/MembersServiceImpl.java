package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MemberDao;
import com.model.Members;

@Service
public class MembersServiceImpl implements IMembersService{

	@Autowired
	MemberDao memberdao;
	
	@Override
	public boolean memberexistsById(int member_id) {
		// TODO Auto-generated method stub
		return memberdao.memberexistsById(member_id);
	}

	@Override
	public Members memberfindById(int member_id) {
		// TODO Auto-generated method stub
		return memberdao.memberfindById(member_id);
	}

	@Override
	public void updatemember_bookone(int book_id, int member_id) {
		memberdao.updatemember_bookone(book_id,member_id);
		
	}@Override
	public void updatemember_booktwo(int book_id, int member_id) {
		memberdao.updatemember_booktwo(book_id,member_id);
		
	}

	@Override
	public void memberdeletebyid(int member_id) {
		memberdao.memberdeletebyid(member_id);
		
	}

	@Override
	public void membersavebyid(Members member) {
		memberdao.membersavebyid(member);
		
	}

	@Override
	public void book_one_return(int member_id) {
		memberdao.book_one_return(member_id);
		
	}

	@Override
	public void book_two_return(int member_id) {
		memberdao.book_two_return(member_id);
		
	}

}

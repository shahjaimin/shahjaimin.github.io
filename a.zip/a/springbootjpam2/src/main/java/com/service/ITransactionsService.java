package com.service;

import com.model.Tranactions;

public interface ITransactionsService {

	void transactionsave(Tranactions t);

	int get_transaction(int book_id, int member_id);

	void update(int id,String sDate);

	

	

	

}

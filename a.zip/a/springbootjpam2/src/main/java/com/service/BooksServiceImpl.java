package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.BooksDao;
import com.model.Books;

@Service
public class BooksServiceImpl implements IBooksService{

	@Autowired
	BooksDao booksdao;

	@Override
	public boolean bookexistsById(int book_id) {
		return booksdao.bookexistsById(book_id);
	}

	@Override
	public Books bookfindById(int book_id) {
		return booksdao.bookfindById(book_id);
	}
	
	@Override
	public void updatebook_free(int book_id) {
		booksdao.updatebook_free(book_id);
	}

	@Override
	public void boookdeletebyid(int book_id) {
		booksdao.boookdeletebyid(book_id);
		
	}

	public void booksavebyid(Books book) {
		booksdao.booksavebyid(book);
		
	}

	@Override
	public void book_update_available(int book_id) {
		booksdao.book_update_available(book_id);
		
	}

	
	
}

package com.service;

import com.model.Books;

public interface IBooksService {

	boolean bookexistsById(int book_id);
	public Books bookfindById(int book_id);
	public void updatebook_free(int book_id);
	void boookdeletebyid(int book_id);
	
	void booksavebyid(Books book);
	void book_update_available(int book_id);

}

package com.service;

import com.model.Members;

public interface IMembersService {

	boolean memberexistsById(int member_id);

	Members memberfindById(int member_id);

	void updatemember_bookone(int book_id, int member_id);
	void updatemember_booktwo(int book_id, int member_id);

	void memberdeletebyid(int member_id);

	void membersavebyid(Members member);

	void book_one_return(int member_id);

	void book_two_return(int member_id);

	



}

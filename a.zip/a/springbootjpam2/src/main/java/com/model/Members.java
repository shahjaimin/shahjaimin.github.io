package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Members {

	@Id
	int member_id;
	
	String member_name;
	String member_type;
	int book_one;
	int book_two;
	public int getMember_id() {
		return member_id;
	}
	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMember_type() {
		return member_type;
	}
	public void setMember_type(String member_type) {
		this.member_type = member_type;
	}
	public int getBook_one() {
		return book_one;
	}
	public void setBook_one(int book_one) {
		this.book_one = book_one;
	}
	public int getBook_two() {
		return book_two;
	}
	public void setBook_two(int book_two) {
		this.book_two = book_two;
	}
	@Override
	public String toString() {
		return "Members [member_id=" + member_id + ", member_name=" + member_name + ", member_type=" + member_type
				+ ", book_one=" + book_one + ", book_two=" + book_two + "]";
	}
	
	
	
}

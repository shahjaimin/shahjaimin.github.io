package com.model;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class UserDate {
	
	
	
	
	String today;
	String today_seven;
	String today_ten;
	
	
	
	
	public UserDate() {
		super();
		Calendar calendar = Calendar.getInstance();     
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String today= dateFormat.format(calendar.getTime());
		this.today=today;
		calendar.add(Calendar.DAY_OF_MONTH,7);  
		String today_seven= dateFormat.format(calendar.getTime());
		this.today_seven=today_seven;
		calendar.add(Calendar.DAY_OF_MONTH,3);  
		String today_ten= dateFormat.format(calendar.getTime());
		this.today_ten=today_ten;
	}

	


	public String getToday() {
		return today;
	}




	public void setToday(String today) {
		this.today = today;
	}




	public String getToday_seven() {
		return today_seven;
	}




	public void setToday_seven(String today_seven) {
		this.today_seven = today_seven;
	}




	public String getToday_ten() {
		return today_ten;
	}




	public void setToday_ten(String today_ten) {
		this.today_ten = today_ten;
	}
	

}

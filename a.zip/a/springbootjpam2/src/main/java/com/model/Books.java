package com.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Books {

	@Id
	int book_id;
	String book_name;
	int book_edition;
	String book_free;
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public int getBook_edition() {
		return book_edition;
	}
	public void setBook_edition(int book_edition) {
		this.book_edition = book_edition;
	}
	public String getBook_free() {
		return book_free;
	}
	public void setBook_free(String book_free) {
		this.book_free = book_free;
	}
	
	@Override
	public String toString() {
		return "Books [book_id=" + book_id + ", book_name=" + book_name + ", book_edition=" + book_edition
				+ ", book_free=" + book_free + "]";
	}
	
	
	
	
}

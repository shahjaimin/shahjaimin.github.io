package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;




import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FacultySkillBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;
@Repository
@Transactional
public class TrainingDaoImpl implements ITrainingDao {
	List<String> courseCodeList;
	
	@PersistenceContext
	private EntityManager entityManager; 
	
	@Override
	public EmployeeBean getUserDetails(String employeeId)
			throws FeedbackException {
		EmployeeBean employee = entityManager.find(EmployeeBean.class, employeeId);
		entityManager.flush();
		return employee;
	}

	@Override
	public List<CourseBean> getCourseCodes() {
		TypedQuery<CourseBean> query = entityManager.createQuery("SELECT courseBean FROM CourseBean courseBean", CourseBean.class);
		return query.getResultList();
	}

	@Override
	public List<FacultySkillBean> getFacultyCode() {
		TypedQuery<FacultySkillBean> query = entityManager.createQuery("SELECT facultySkillBean FROM FacultySkillBean facultySkillBean", FacultySkillBean.class);
		
		return query.getResultList();
	}

	@Override
	public TrainingProgramBean addProgram(TrainingProgramBean programBean) {
		entityManager.persist(programBean);
		return programBean;
	}

	@Override
	public TrainingProgramBean fetchProgram(TrainingProgramBean programBean) {
		programBean=entityManager.find(TrainingProgramBean.class,programBean.getTrainingCode());
		
		if(programBean==null){
			return null;
		}
		else{
			return programBean;
		}
	}

	@Override
	public TrainingProgramBean updateProgram(TrainingProgramBean programBean) {
		entityManager.merge(programBean);
		return programBean;
	}

	@Override
	public TrainingProgramBean deleteProgram(TrainingProgramBean programBean){
		TrainingProgramBean bean=null;
	
		
			bean=entityManager.find(TrainingProgramBean.class,programBean.getTrainingCode());
					if(bean!=null)
					{
						entityManager.remove(bean);
					}
					else
						return null;
		
		return bean;
		
	}

	
	

}

package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FacultySkillBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;

public interface ITrainingDao {
	
	public abstract EmployeeBean getUserDetails(String employeeId) throws FeedbackException;

	public abstract List<CourseBean> getCourseCodes();

	public abstract 	List<FacultySkillBean> getFacultyCode();

	public abstract TrainingProgramBean addProgram(TrainingProgramBean programBean);

	public abstract TrainingProgramBean fetchProgram(TrainingProgramBean programBean);

	public abstract TrainingProgramBean updateProgram(TrainingProgramBean programBean);

	public abstract TrainingProgramBean deleteProgram(
			TrainingProgramBean programBean);

}

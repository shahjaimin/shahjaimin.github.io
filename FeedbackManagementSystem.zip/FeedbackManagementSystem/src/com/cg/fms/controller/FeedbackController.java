package com.cg.fms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.security.auth.login.LoginContext;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import oracle.net.aso.e;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FacultySkillBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.ITrainingService;

@Controller
public class FeedbackController {

	
	EmployeeBean employee;
	
	@Autowired
	private ITrainingService trainingService;
	
	private List<CourseBean> courseBeanList;
	private List<FacultySkillBean> facultyBeanList;
	private List<Integer> courseCodeList= new ArrayList<Integer>();
	private List<Integer> facultyCodeList= new ArrayList<Integer>();


	@RequestMapping("/index")
	public ModelAndView showLoginPage() throws Exception {
		EmployeeBean login = new EmployeeBean();
		return new ModelAndView("Home", "login", login);
	}
	@RequestMapping("/login")
	public ModelAndView showLogin() throws Exception {
		EmployeeBean login = new EmployeeBean();
		return new ModelAndView("loginPage", "login", login);
	}
	

	@RequestMapping("/checkLogin")
	public ModelAndView authenticateUser(
			@ModelAttribute(value = "login") @Valid EmployeeBean login,
			BindingResult result, Model model) {
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv=	new ModelAndView("loginPage");
			}
		else{
		try {
			if(login.getPassword()!=""&&login.getEmployeeId()!=""){
			employee = trainingService.getUserDetails(login.getEmployeeId());
			System.out.println("hii");
			if (employee != null) {
				if (employee.getPassword().equals(login.getPassword())) {
					if (employee.getRole().equals("admin")) {
						System.out.println("hii");
						model.addAttribute("employeeName",employee.getEmployeeName());
						mv=new ModelAndView("adminPage");
					} else if (employee.getRole().equals("coordinator")) {
						model.addAttribute("employeeName",employee.getEmployeeName());
						mv=new ModelAndView("coordinatorPage");
					} else if (employee.getRole().equals("participant")) {
						model.addAttribute("employeeName",employee.getEmployeeName());
						mv=new ModelAndView("participantPage");
					}
				} else {
					mv=	new ModelAndView("loginPage");
					model.addAttribute("msg", "Password MisMatch!!! Enter valid credentials");
				}

				} else {
					mv=	new ModelAndView("loginPage");
				model.addAttribute("msg", "No User Found! Enter valid credentials");
			}
		}else{
			mv=	new ModelAndView("loginPage");
			model.addAttribute("msg", "Enter all reduired fields");
		} }catch (FeedbackException exception) {

		}
		}
		return mv;
	}

	
	@RequestMapping("/trainingProgramMaintenance")
	public ModelAndView trainingProgramMaintenance() throws Exception {
		return new ModelAndView("trainingMaintenance", "msg", "Training Program Maintenance");
	}
	

	@RequestMapping("/trainingMenu")
	public ModelAndView trainingMenu(Model model){
		return new ModelAndView("coordinatorPage");
	}
	
	@RequestMapping("/addTrainingPrograms")
	public ModelAndView addTrainingPrograms(Model model) throws Exception {
		TrainingProgramBean programBean = new TrainingProgramBean();
		ModelAndView mv = new ModelAndView();
		courseBeanList= trainingService.getCourseCodes();
		courseCodeList.clear();
		for (CourseBean courseBean : courseBeanList) {
			courseCodeList.add(courseBean.getCourseId());
		}
		
		facultyBeanList=trainingService.getFacultyCode();
		facultyCodeList.clear();
		for (FacultySkillBean facultyBean : facultyBeanList) {
			facultyCodeList.add(facultyBean.getFacultyId());
		}

		model.addAttribute("courseCodeList", courseCodeList);
		model.addAttribute("facultyCodeList", facultyCodeList);
		 mv= new ModelAndView("addTrainingPrograms","programBean",programBean);
		 return mv;
	}
	
	@RequestMapping("/addProgram")
	public ModelAndView addProgram(@ModelAttribute(value = "programBean") @Valid TrainingProgramBean programBean, BindingResult result,Model model,@RequestParam("startDate") String startDate,@RequestParam("endDate") String endDate){
		ModelAndView view = new ModelAndView();
		
		
		Date date=java.util.Calendar.getInstance().getTime(); 
		System.out.println(programBean.getEndDate());
		String pagename= "addTrainingPrograms";
		view=validateDates(startDate,endDate,model,programBean,pagename);
		
		if (result.hasErrors()) {
		model.addAttribute("courseCodeList", courseCodeList);
		model.addAttribute("facultyCodeList", facultyCodeList);
		view=new ModelAndView("addTrainingPrograms","programBean",programBean);
		}
		else if (programBean.getStartDate().compareTo(date)<0) {
			
			model.addAttribute("courseCodeList", courseCodeList);
			model.addAttribute("facultyCodeList", facultyCodeList);
			model.addAttribute("M2","Can't have Start date less than Current date");
			view=new ModelAndView("addTrainingPrograms","programBean",programBean);
		}
		else if (programBean.getStartDate().compareTo(programBean.getEndDate())>0) {
			
			model.addAttribute("courseCodeList", courseCodeList);
			model.addAttribute("facultyCodeList", facultyCodeList);
			model.addAttribute("M1","Can't have End date less than Start date");
			view=new ModelAndView("addTrainingPrograms","programBean",programBean);
		}
		
		else{
			programBean= trainingService.addProgram(programBean);
			model.addAttribute("programBean",programBean);
			view=new ModelAndView("successTrainingProgram");
		}
		 return view; 
		}
	
	private ModelAndView validateDates(String startDate, String endDate,Model model,TrainingProgramBean programBean,String pagename) {
		ModelAndView view= new ModelAndView();
		SimpleDateFormat formatter=new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			try {
				
			formatter.parse(startDate);}
			catch (ParseException e) {
				model.addAttribute("startDate1", "Start date should be in format: dd/MM/yyyy");
				model.addAttribute("courseCodeList", courseCodeList);
				model.addAttribute("facultyCodeList", facultyCodeList);
				view=new ModelAndView(pagename,"programBean",programBean);
			}
		
				formatter.parse(endDate);
				
			
		}  catch (ParseException e) {
			model.addAttribute("endDate1", "End date should be in format: dd/MM/yyyy");
			model.addAttribute("courseCodeList", courseCodeList);
			model.addAttribute("facultyCodeList", facultyCodeList);
			view=new ModelAndView(pagename,"programBean",programBean);
			
			// TODO Auto-generated catch block
			
		}return view;
	}

	@RequestMapping("/getTrainingProgramById")
	public ModelAndView getTrainingProgramById(Model model){
		TrainingProgramBean programBean = new TrainingProgramBean();
		return new ModelAndView("viewTrainingProgram","programBean",programBean);
	}

	@RequestMapping("/deleteTrainingProgramById")
	public ModelAndView deleteTrainingProgramById(Model model){
		TrainingProgramBean programBean = new TrainingProgramBean();
		return new ModelAndView("delete","programBean",programBean);
	}
	@RequestMapping("/fetchProgram")
	public ModelAndView fetchProgram(@ModelAttribute(value = "programBean") @Valid TrainingProgramBean programBean, BindingResult result,Model model){
	ModelAndView view = new ModelAndView();
		if (programBean.getTrainingCode()>=1 && programBean.getTrainingCode()<100000) {
			TrainingProgramBean programBean1=trainingService.fetchProgram(programBean);
			if (programBean1==null) {
				model.addAttribute("msg", "No data Found for given Training Code");
				view=new ModelAndView("viewTrainingProgram","programBean",programBean);
			}else {
				view=new ModelAndView("viewTrainingProgram","programBean",programBean1);
				}
		}else {
			model.addAttribute("msg", "Enter Valid Training Code Minimum of 1 digits");
			view =new ModelAndView("viewTrainingProgram","programBean",programBean);
			}
		return view;
	}

	@RequestMapping("/deleteProgram")
	public ModelAndView deleteProgram(@ModelAttribute(value = "programBean") @Valid TrainingProgramBean programBean, BindingResult result,Model model){
	ModelAndView view = new ModelAndView();
		if (programBean.getTrainingCode()>=1 && programBean.getTrainingCode()<1000) {
			TrainingProgramBean programBean1 = null;
			
				programBean1 = trainingService.deleteProgram(programBean);
			
			if (programBean1==null) {
				model.addAttribute("msg", "No data Found for given Training Code");
				view=new ModelAndView("delete","programBean",programBean);
			}else {
				model.addAttribute("msg", "Deleted Successfully");
				view=new ModelAndView("delete","programBean",programBean1);
				}
		}else {
			model.addAttribute("msg", "Enter Valid Training Code Minimum of 1 digits");
			view =new ModelAndView("delete","programBean",programBean);
			}
		return view;
	}
	@RequestMapping("/updateTrainingProgram")
	public ModelAndView updateTrainingProgram(Model model){
		TrainingProgramBean programBean = new TrainingProgramBean();
		facultyBeanList=trainingService.getFacultyCode();
		facultyCodeList.clear();
		for (FacultySkillBean facultyBean : facultyBeanList) {
			facultyCodeList.add(facultyBean.getFacultyId());
		}
		return new ModelAndView("updateTrainingProgram","programBean",programBean);
	}
	
	@RequestMapping("/retriveProgram")
	public ModelAndView retriveProgram(@ModelAttribute(value = "programBean") @Valid TrainingProgramBean programBean, BindingResult result,Model model){
		ModelAndView view = new ModelAndView();
		if (programBean.getTrainingCode()>=1 && programBean.getTrainingCode()<100000) {
			TrainingProgramBean programBean1=trainingService.fetchProgram(programBean);
			if (programBean1==null) {
				model.addAttribute("noDatamsg", "No data Found for given Training Code");
				programBean.setStartDate(new TrainingProgramBean().getStartDate());
				view=new ModelAndView("updateTrainingProgram","programBean",programBean);
			}else {
				model.addAttribute("facultyCodeList", facultyCodeList);
				view=new ModelAndView("updateTrainingProgram","programBean",programBean1);
				}
		}else {
			model.addAttribute("triningcodevalidate", "Enter Valid Training Code of Minimum 1 digits");
			view =new ModelAndView("updateTrainingProgram","programBean",programBean);
			}
		
		return view;
	}
	
	
	@RequestMapping("/updateProgram")
	public ModelAndView updateProgram(@ModelAttribute(value = "programBean") @Valid TrainingProgramBean programBean, BindingResult result,Model model,@RequestParam("startDate") String startDate,@RequestParam("endDate") String endDate){
		
		Date date=java.util.Calendar.getInstance().getTime(); 
		String pagename= "updateTrainingProgram";
		ModelAndView view = new ModelAndView();
	
		
		view=validateDates(startDate,endDate,model,programBean,pagename);
		if (result.hasErrors()) {
			model.addAttribute("facultyCodeList", facultyCodeList);
		
			view=new ModelAndView("updateTrainingProgram","programBean",programBean);
			}
			else if (programBean.getStartDate().compareTo(date)<0) {
			
				model.addAttribute("facultyCodeList", facultyCodeList);
				model.addAttribute("dateCompare2","Can't have start date less than current date");
				view=new ModelAndView("updateTrainingProgram","programBean",programBean);
		}
			else if (programBean.getStartDate().compareTo(programBean.getEndDate())>0) {
				model.addAttribute("facultyCodeList", facultyCodeList);
				model.addAttribute("dateCompare","Can't have End date less than Start date");
				view=new ModelAndView("updateTrainingProgram","programBean",programBean);
			}
			else{
				programBean= trainingService.updateProgram(programBean);
				model.addAttribute("programBean",programBean);
				view=new ModelAndView("updateSuccessProgram");
			}
		
		return view;
	}
}

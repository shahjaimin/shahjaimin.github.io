package com.cg.fms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FacultySkillBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.dao.ITrainingDao;
import com.cg.fms.exception.FeedbackException;

@Service
public class TrainingServiceImpl implements ITrainingService{

	
	@Autowired
	ITrainingDao trainingDao;
	
	@Override
	public EmployeeBean getUserDetails(String employeeId) throws FeedbackException {
		// TODO Auto-generated method stub
		return trainingDao.getUserDetails(employeeId);
	}

	
	@Override
	public List<CourseBean> getCourseCodes() {
		return trainingDao.getCourseCodes();
	}

	@Override
	public List<FacultySkillBean> getFacultyCode() {
		return trainingDao.getFacultyCode();
	}

	@Override
	public TrainingProgramBean addProgram(TrainingProgramBean programBean) {
		return trainingDao.addProgram( programBean);
	}

	@Override
	public TrainingProgramBean fetchProgram(TrainingProgramBean programBean) {
		return trainingDao.fetchProgram( programBean);
	}

	@Override
	public TrainingProgramBean updateProgram(TrainingProgramBean programBean) {
		return trainingDao.updateProgram( programBean);
	}


	@Override
	public TrainingProgramBean deleteProgram(TrainingProgramBean programBean)
			 {
		// TODO Auto-generated method stub
		return trainingDao.deleteProgram( programBean);
	}


}

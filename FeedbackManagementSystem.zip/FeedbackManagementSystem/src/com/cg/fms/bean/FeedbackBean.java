package com.cg.fms.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Feedback_Master")
public class FeedbackBean {
	@Id
	private int feedbackId;
	private int trainigCode;
	private int participantId;
	private int fbPrsComm;
	private int fbClrfyDbts;
	private int fbTm;
	private int fbHndOut;
	private int fbHwSwNtwrk;
	private String comments;
	private String suggestions;
	public int getTrainigCode() {
		return trainigCode;
	}
	public void setTrainigCode(int trainigCode) {
		this.trainigCode = trainigCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public int getFbPrsComm() {
		return fbPrsComm;
	}
	public void setFbPrsComm(int fbPrsComm) {
		this.fbPrsComm = fbPrsComm;
	}
	public int getFbClrfyDbts() {
		return fbClrfyDbts;
	}
	public void setFbClrfyDbts(int fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}
	public int getFbTm() {
		return fbTm;
	}
	public void setFbTm(int fbTm) {
		this.fbTm = fbTm;
	}
	public int getFbHndOut() {
		return fbHndOut;
	}
	public void setFbHndOut(int fbHndOut) {
		this.fbHndOut = fbHndOut;
	}
	public int getFbHwSwNtwrk() {
		return fbHwSwNtwrk;
	}
	public void setFbHwSwNtwrk(int fbHwSwNtwrk) {
		this.fbHwSwNtwrk = fbHwSwNtwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	@Override
	public String toString() {
		return "FeedbackBean [trainigCode=" + trainigCode + ", participantId="
				+ participantId + ", fbPrsComm=" + fbPrsComm + ", fbClrfyDbts="
				+ fbClrfyDbts + ", fbTm=" + fbTm + ", fbHndOut=" + fbHndOut
				+ ", fbHwSwNtwrk=" + fbHwSwNtwrk + ", comments=" + comments
				+ ", suggestions=" + suggestions + "]";
	}
	
	
}

package com.cg.fms.bean;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Training_Program")
public class TrainingProgramBean {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trainingCodeSeq")
	@SequenceGenerator(sequenceName = "trainingCodeSeq", name = "trainingCodeSeq", initialValue=1, allocationSize=1) 
	private int trainingCode;
	
	@Min(1)
	private int courseCode;
	@Min(1000)
	private int facultyCode;
	
	@Temporal(TemporalType.DATE)
	@NotNull
	@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date startDate;
	
	@Temporal(TemporalType.DATE)
	@NotNull
	@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date endDate;

	public int getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}

	public int getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(int courseCode) {
		this.courseCode = courseCode;
	}

	public int getFacultyCode() {
		return facultyCode;
	}

	public void setFacultyCode(int facultyCode) {
		this.facultyCode = facultyCode;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "TrainingProgramBean [trainingCode=" + trainingCode
				+ ", courseCode=" + courseCode + ", facultyCode=" + facultyCode
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
	
}

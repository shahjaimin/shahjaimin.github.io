package com.cg.fms.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FACULTY_SKILL")
public class FacultySkillBean {
	
	@Id
	private int facultyId;
	
	private String skillSet;

	public int getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	@Override
	public String toString() {
		return "FacultySkillBean [facultyId=" + facultyId + ", skillSet="
				+ skillSet + "]";
	}
	
	
}

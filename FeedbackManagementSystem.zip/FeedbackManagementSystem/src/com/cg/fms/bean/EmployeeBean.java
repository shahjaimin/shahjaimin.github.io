package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;


@Entity
@Table(name="Employee_Master")
public class EmployeeBean {

@Id
@Size(min=4,max=4,message="Employee Id should be 4 characters only")
private String employeeId;

private String employeeName;
@Size(min=4,message="Password should be minimum 4 characters")
private String password;

private String role;


public String getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(String employeeId) {
	this.employeeId = employeeId;
}

public String getEmployeeName() {
	return employeeName;
}

public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

@Override
public String toString() {
	return "EmployeeBean [employeeId=" + employeeId + ", employeeName="
			+ employeeName + ", password=" + password + ", role=" + role + "]";
}

public EmployeeBean() {
	super();
	// TODO Auto-generated constructor stub
}




}

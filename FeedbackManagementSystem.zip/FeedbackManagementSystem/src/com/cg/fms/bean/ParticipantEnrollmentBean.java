package com.cg.fms.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainingparticipant_Enrollment")
public class ParticipantEnrollmentBean {
	
	@Id
	private int enrollId;
	private int trainingCode;
	
	private int participantId;

	public int getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}

	public int getParticipantId() {
		return participantId;
	}

	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}

	@Override
	public String toString() {
		return "ParticipantEnrollmentBean [trainingCode=" + trainingCode
				+ ", participantId=" + participantId + "]";
	}
	
	
}

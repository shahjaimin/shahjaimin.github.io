package com.lib;

@Controller
public class LibController{

	@RequestMapping("/add")
	public String addmethod()
	{
		return "dis.jsp";
	}
}
